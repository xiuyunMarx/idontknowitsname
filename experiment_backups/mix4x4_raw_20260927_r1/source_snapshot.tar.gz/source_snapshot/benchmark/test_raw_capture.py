"""GPU-free checks for raw request/session recording and batch backups."""
import ast
import asyncio
import contextlib
import csv
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import threading
import time
import typing
import unittest
from unittest.mock import patch

from benchmark import mixed_workload, rerun_mixed_raw
from model.request_trace import RequestTrace


def events(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def generate_method():
    # Exercise the real method without importing GPU libraries or loading weights.
    tree = ast.parse((Path(__file__).resolve().parents[1] / 'model/model.py').read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Engine')
    node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'generate')
    namespace = dict(vars(typing), time=time, PRIORITY_REAL=1)
    exec(compile(ast.Module(body=[node], type_ignores=[]), 'model/model.py', 'exec'), namespace)
    return namespace['generate']


class CaptureTests(unittest.IsolatedAsyncioTestCase):
    async def exercise(self, failure=None):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'requests.jsonl'
            with patch.dict(os.environ, {'BENCH_REQUEST_LOG': str(path)}):
                trace = RequestTrace()

            class Backend:
                async def async_generate(self, **kwargs):
                    async def stream():
                        if failure == 'before':
                            raise RuntimeError('before token')
                        yield {'text': 'a', 'output_ids': [1], 'meta_info': {
                            'prompt_tokens': 100, 'cached_tokens': 60,
                            'cached_device': 40, 'cached_host': 20}}
                        if failure == 'after':
                            raise RuntimeError('after token')
                        if failure == 'cancel':
                            raise asyncio.CancelledError()
                        yield {'text': 'ab', 'output_ids': [1, 2]}
                    return stream()

            class Engine:
                generate = generate_method()
                engine = Backend()
                request_trace = trace
                sp = {'temperature': 0}
                _inflight_prefill = _inflight_decode = 0
                last = {}
                def _cache_stats(self, meta):
                    return dict(meta)
                def _calibrate(self, ids, stats):
                    pass
                def note_landed(self, ids):
                    pass

            engine = Engine()
            with contextlib.redirect_stdout(io.StringIO()):
                if failure:
                    with self.assertRaises(asyncio.CancelledError if failure == 'cancel' else RuntimeError):
                        await engine.generate('prompt', '42-1t0-test', ids=[1] * 100)
                else:
                    self.assertEqual(await engine.generate('prompt', '42-1t0-test', ids=[1] * 100), 'ab')
            # Data must be readable while the trace is still open.
            rows = events(path)
            trace.close()
            self.assertEqual(engine._inflight_prefill, 0)
            self.assertEqual(engine._inflight_decode, 0)
            self.assertEqual(rows[0]['event'], 'request_start')
            self.assertEqual(rows[-1]['event'], 'request_end')
            self.assertEqual(rows[-1]['completed'], failure is None)
            self.assertEqual(rows[-1]['received_first_token'], failure != 'before')
            self.assertTrue(all(r['time_ns'] > 0 and r['monotonic_ns'] > 0 for r in rows))
            self.assertEqual([r['monotonic_ns'] for r in rows], sorted(r['monotonic_ns'] for r in rows))
            if failure != 'before':
                first = rows[1]
                self.assertEqual(first['event'], 'first_token')
                self.assertEqual(first['prompt_tokens'], 100)
                self.assertEqual(first['cached_device'] + first['cached_host'], first['cached_tokens'])
                self.assertGreaterEqual(first['ttft_ms'], 0)
            if failure:
                self.assertIsNotNone(rows[-1]['error'])

    async def test_success(self):
        await self.exercise()

    async def test_failure_before_first_token(self):
        await self.exercise('before')

    async def test_failure_after_first_token(self):
        await self.exercise('after')

    async def test_cancellation(self):
        await self.exercise('cancel')


class SessionTests(unittest.TestCase):
    def test_source_snapshot_excludes_jac_cache_directories(self):
        paths = rerun_mixed_raw.sources()
        self.assertTrue(paths)
        self.assertTrue(all(p.is_file() for p in paths))
        self.assertEqual(len(rerun_mixed_raw.hashes(paths)), len(paths))

    def test_concurrent_sessions_are_saved_before_run_finishes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_jac = root / 'jac'
            fake_jac.write_text('#!/bin/sh\nprintf "Verdict: PASSED\\nRounds: 2, notes: 3\\n"\n')
            fake_jac.chmod(0o755)
            out = root / 'run'
            runner = mixed_workload.Runner('test', 5, str(out))
            with patch.object(mixed_workload, 'JAC', str(fake_jac)), contextlib.redirect_stdout(io.StringIO()):
                threads = [threading.Thread(target=runner.run_session,
                           args=('fact_check', {'idx': i, 'input': 'test', 'expected': 'PASSED'}, 'measured', f'fact_check-{i}', True)) for i in range(4)]
                for thread in threads:
                    thread.start()
                for thread in threads:
                    thread.join()
            rows = events(out / 'sessions.jsonl')
            ev = events(out / 'session_events.jsonl')
            self.assertEqual(len(rows), 4)
            self.assertEqual(len(ev), 8)
            self.assertTrue(all(r['rc'] == 0 and r['verdict'] == 'PASSED' for r in rows))
            self.assertEqual({r['pid'] for r in rows}, {r['pid'] for r in ev})
            with self.assertRaises(FileExistsError):
                mixed_workload.Runner('test', 5, str(out))
            self.assertEqual(events(out / 'sessions.jsonl'), rows)
            runner.records_file.close()
            runner.events_file.close()

    def test_backup_round_trip_and_arm_plan(self):
        self.assertEqual(len(rerun_mixed_raw.ARMS), 11)
        self.assertEqual(len({arm for arm, _, _ in rerun_mixed_raw.ARMS}), 11)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / 'arm'
            src.mkdir()
            raw = b'{"event":"first_token","cached_host":17}\n'
            (src / 'requests.jsonl').write_bytes(raw)
            target = root / 'arm.tar.gz'
            rerun_mixed_raw.archive(src, target)
            with tarfile.open(target) as tar:
                self.assertEqual(tar.extractfile('arm/requests.jsonl').read(), raw)
            self.assertTrue(target.with_suffix('.gz.sha256').exists())


if __name__ == '__main__':
    unittest.main()
